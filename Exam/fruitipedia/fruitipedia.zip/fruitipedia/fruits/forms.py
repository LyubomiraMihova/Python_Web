from django import forms


class FruitForm(forms.Form):
    pass